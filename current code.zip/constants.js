const pathColors = {
    harvester: '#ffaa00',
    hauler: '#00d0ff',
    supplier: '#00ff00',
    builder: '#b266ff',
    repairer: '#ff6600',
    upgrader: '#3377ff',
    scout: '#cccccc',
    retrieve: '#ffffff'
};

module.exports = { pathColors };